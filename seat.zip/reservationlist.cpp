#include "ReservationList.h"
#include <iostream>
using namespace std;

ReservationList::ReservationList() : head(nullptr) {}

ReservationList::~ReservationList() {}

void ReservationList::DisplaySeats() {
    Seat* current = head;

    if (!current) {
        cout << "No seats to display." << endl;
        return;
    }

    cout << "Seats:" << endl;
    while (current) {
        cout << "Seat Number: " << current->seatnumber << " | Status: " << current->status << " | Passenger Name: " << current->name << endl;
        current = current->next;
    }
    cout << "\t\t\t********************\t\t\t" << endl;
}

void ReservationList::CancelTicket(int seatNumber) {
    Seat* current = head;

    while (current) {
        if (current->seatnumber == seatNumber) {
            if (current->prev) {
                current->prev->next = current->next;
            }
            else {
                head = current->next;
            }

            if (current->next) {
                current->next->prev = current->prev;
            }

            delete current;
           cout << "Ticket for seat number " << seatNumber << " canceled successfully." << endl;
            return;
        }
        
        current = current->next;
    }

    cout << "Seat number " << seatNumber << " not found. No ticket canceled." << endl;
    cout << "\t\t\t********************\t\t\t" << endl;
}

void ReservationList::DisplayReservedSeats() {
    Seat* current = head;

    if (!current) {
        cout << "No seats to display." << endl;
        return;
    }

    cout << "Reserved Seats:" << endl;
    while (current) {
        if (current->status == "BOOKED") {
            cout << "Seat Number: " << current->seatnumber << " | Status: " << current->status << " | Passenger Name: " << current->name << endl;
        }
        current = current->next;
    }
}

void ReservationList::GetSeatInformation(int seatNumber) {
    Seat* current = head;

    while (current) {
        if (current->seatnumber == seatNumber) {
            cout << "Seat Number: " << current->seatnumber << " | Status: " << current->status << " | Passenger Name: " << current->name << endl;
            return;
        }

        current = current->next;
    }

    cout << "Seat number " << seatNumber << " not found." << endl;
    cout << "\t\t\t********************\t\t\t" << endl;
}

void ReservationList::UpdateSeatInformation(int seatNumber) {
    Seat* current = head;

    while (current) {
        if (current->seatnumber == seatNumber) {
            cout << "Enter the new status for seat " << seatNumber << ": ";
            cin >> current->status;

            cout << "Enter the new passenger name for seat " << seatNumber << ": ";
            cin >> current->name;

            cout << "Seat information updated successfully." << endl;
            return;
        }

        current = current->next;
    }

    cout << "Seat number " << seatNumber << " not found. No information updated." << endl;
    cout << "\t\t\t********************\t\t\t" << endl;
}
