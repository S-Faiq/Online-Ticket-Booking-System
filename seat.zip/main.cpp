#include "ReservationList.h"
#include <iostream>
using namespace std;

int main() {
    ReservationList reservationList;

    reservationList.head = new Seat;

    reservationList.head->BookTicket("faiq", 23);
    reservationList.head->BookTicket("ali", 34);
    reservationList.head->BookTicket("ahmad", 3);

    reservationList.DisplaySeats();

    int seatToCancel=23;
    reservationList.CancelTicket(seatToCancel);
    cout << "\t\t\t********************\t\t\t" << endl;
    cout << "Your searched seat is: ";
    int seatToFind=3;
    reservationList.GetSeatInformation(seatToFind);
    cout << "\t\t\t********************\t\t\t" << endl;
    int seatToUpdate;
    cout << "Enter the seat number to update information: ";
    cin >> seatToUpdate;
    cout << "\t\t\t********************\t\t\t" << endl;
    reservationList.UpdateSeatInformation(seatToUpdate);

    reservationList.DisplaySeats();

    return 0;
}
