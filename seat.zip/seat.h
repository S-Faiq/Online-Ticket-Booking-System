#include <iostream>
#include <string>
using namespace std;

class Seat {
public:
    int count;
    int seatnumber;
    string status;
    string name;
    Seat* next;
    Seat* prev;

    Seat();
    ~Seat();
    void BookTicket(string passengerName, int seatNumber);
};
