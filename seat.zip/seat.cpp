#include "seat.h"
#include <iostream>

Seat::Seat() : count(0), seatnumber(0), status(""), next(nullptr), prev(nullptr) {}

Seat::~Seat() {}

void Seat::BookTicket(string passengerName, int seatNumber) {
    Seat* newNode = new Seat;
    newNode->name = passengerName;
    newNode->seatnumber = seatNumber;

    newNode->status = "BOOKED";
    if (!next) {
        next = prev = newNode;
    }
    else {
        prev->next = newNode;
        newNode->prev = prev;
        prev = newNode;
    }
    count++;
    cout << "Ticket booked successfully..!" << endl;
    cout << "\t\t\t********************\t\t\t" << endl;
}
