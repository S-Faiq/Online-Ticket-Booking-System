#include "seat.h"

class ReservationList {
public:
    Seat* head;
    ReservationList();
    ~ReservationList();
    void DisplaySeats();
    void CancelTicket(int seatNumber);
    void DisplayReservedSeats();
    void GetSeatInformation(int seatNumber);
    void UpdateSeatInformation(int seatNumber);
};
